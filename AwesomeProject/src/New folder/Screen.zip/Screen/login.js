import React from "react";
import {Pressable,Button, Text, ImageBackground, View, Image,SafeAreaView, StyleSheet, TextInput } from "react-native";

const UselessTextInput = () => {
  const [text, onChangeText] = React.useState(null);
  const [number, onChangeNumber] = React.useState(null);
  const image = { uri: "https://cdn.discordapp.com/attachments/511466864925343744/916519700714913812/background-159244_640.png" };
  return (
    
    <View style={styles.container}>
      <ImageBackground source={image} resizeMode="cover" style={styles.image}>
      <View style={styles.logofadal}>
      <Image
        style={styles.logo}
        source={{
          uri: 'https://cdn.discordapp.com/attachments/511466864925343744/914762174314979378/Logo2.png',
        }}
      />
      <Text style={styles.logofadal}>Silahkan Masukkan ID</Text>
      </View>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        value={text}
        placeholder="Masukkan Username"
      />
      <TextInput
        secureTextEntry={true}
        style={styles.input}
        onChangeText={onChangeNumber}
        value={number}
        placeholder="Masukkan PIN"
        keyboardType="numeric"
      />
      <View style={styles.fixToText}>
        <Button
          title="Login"
          onPress={() => Alert.alert('Login')}
        />
      </View>
      <View style={styles.disini}>
      <Text style={styles.akun}>Belum memiliki akun? Silahkan mendaftar terlebih dahulu</Text>
      <Text style={styles.disini}> disini </Text>
      {/* <Pressable onPress={onPressFunction}>
      <Text>I'm pressable!</Text>
      </Pressable> https://reactnative.dev/docs/pressable */}
      </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    borderRadius:20,
    borderColor:'white',
    backgroundColor:'white',
  },
  container: {
    flex: 1,
  },
  logo: {
    width:250,
    height:250,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bg: {
    flex: 1,
    justifyContent: "center"
  },
  image: {
    flex: 1,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    justifyContent: "center",
  },
  logofadal: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  akun: {
    marginTop: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  disini: {
    color: 'red',
    alignItems: 'center',
    justifyContent: 'center',
  },
  
});

export default UselessTextInput;