import React from "react";
import {Pressable,Button, Text, ImageBackground, View, Image,SafeAreaView, StyleSheet, TextInput, TouchableHighlight} from "react-native";

const UselessTextInput = () => {
  const [text, onChangeText, OrderID,berat,harga,stat] = React.useState(null);
  const [number, onChangeNumber] = React.useState(null);
  return (
    
    <View style={styles.container}>
      
    <ImageBackground source={require('./assets/background2.png')} resizeMode="cover" style={styles.image}>
    
      <View style={styles.bg}>
      
      <Text style={styles.teks}> Foto Profile</Text>
      
      <Image style={styles.foto}
        source={require('./assets/profile.jpg')} />
      
      
      <Text style={styles.edit}> Edit Foto </Text>

      <Text style={styles.nama} > Nama Lengkap </Text>
      <TextInput style={styles.isi}> Fadhlil Azhim Firmansyah </TextInput>
      <Text style={styles.nama}> Nomor Telepon </Text>
      <TextInput style={styles.isi}> +628123456789 </TextInput>
      <Text style={styles.nama}> Email </Text>
      <TextInput style={styles.isi}> email@email.com </TextInput>
      
      
      <TouchableHighlight style={styles.tengah}>         
        
        <View style={styles.button}>           
        <Text style={{color: 'black', fontSize: 18,}}> 
        Update 
        </Text>         
        </View>
        </TouchableHighlight>
      </View >

    

      
      </ImageBackground>
    </View>
    
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  foto: {
    width:100,
    height:100,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius:100/2,
  },
  image: {
    flex: 1,
  },
  bg: {
    flex: 1,
    marginTop: 40,
    marginHorizontal: 10,
  },
  teks:{
    left:13,
    fontWeight: 'bold',
    bottom:4,
  },
  edit:{
    top:5,
    left:20,
    color: '#545454',
  },
  nama:{
    fontWeight: 'bold',
    top:50,
    fontSize:15,
  },
  isi:{
    borderBottomColor: 'black',
    borderBottomWidth: 1,
    top:50,
    fontSize:15,
  },
  button: {
    alignItems: "center",
    justifyContent: 'center',
    backgroundColor: "lightgreen",
    padding: 10,
    borderColor: 'black',
    height: 50,
    width: 200,
    borderWidth: 1,
    borderRadius:25,
  },
  tengah:{
    top:150,
    alignItems: "center",
    justifyContent: 'center',
  },
  logout:{
    width:50,
    height:50,
    
  }
});

export default UselessTextInput;