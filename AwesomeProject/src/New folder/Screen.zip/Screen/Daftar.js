import React from "react";
import {Pressable,Button, Text, ImageBackground, View, Image,SafeAreaView, StyleSheet, TextInput } from "react-native";

const UselessTextInput = () => {
  const [text, nama,alamat,notel,user,pass] = React.useState(null);
  const [number, onChangeNumber] = React.useState(null);
  const image = { uri: "https://cdn.discordapp.com/attachments/511466864925343744/916519700714913812/background-159244_640.png" };
  return (
    
    <View style={styles.container}>
      <ImageBackground source={image} resizeMode="cover" style={styles.image}>
      <View style={styles.logofadal}>
      <Image
        style={styles.logo}
        source={{
          uri: 'https://cdn.discordapp.com/attachments/511466864925343744/914762174314979378/Logo2.png',
        }}
      />
      </View>
      <TextInput
        style={styles.input}
        onChangeText={nama}
        value={nama}
        placeholder="Nama"
      />
      <TextInput
        style={styles.input}
        onChangeText={alamat}
        value={alamat}
        placeholder="Alamat"
      />
      <TextInput
        style={styles.input}
        onChangeText={notel}
        value={notel}
        placeholder="No Telepon"
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        onChangeText={user}
        value={user}
        placeholder="Username"
      />
      <TextInput
        secureTextEntry={true}
        style={styles.input}keyboardType="numeric"
        onChangeText={pass}
        value={pass}
        placeholder="Masukkan PIN"
        keyboardType="numeric"keyboardType="numeric"
      />
      <View style={styles.fixToText}>
        <Button
          title="Daftar"
          onPress={() => Alert.alert('Daftar')}
        />
      </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    borderRadius:20,
    borderColor:'white',
    backgroundColor:'white',
  },
  container: {
    flex: 1,
  },
  logo: {
    width:150,
    height:150,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bg: {
    flex: 1,
    justifyContent: "center"
  },
  image: {
    flex: 1,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    justifyContent: "center",
  },
  logofadal: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default UselessTextInput;